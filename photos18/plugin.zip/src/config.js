BASE_URL="https://www.photos18.com"
PER_PAGE="100"
