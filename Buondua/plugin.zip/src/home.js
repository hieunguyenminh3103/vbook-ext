function execute() {
    return Response.success([
        {title: "Update", input: "https://buondua.com/", script: "gen.js"},
        {title: "Hot", input: "https://buondua.com/hot/", script: "gen.js"},
        {title: "Xiuren", input: "https://buondua.com/tag/7417/", script: "gen.js"},
        {title: "Cosplay", input: "https://buondua.com/tag/10688/", script: "gen.js"},
        {title: "AI Generated", input: "https://buondua.com/tag/11406/", script: "gen.js"},
    ]);
}
