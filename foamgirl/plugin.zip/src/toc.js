load('config.js');
function execute(url) {
    var browser = Engine.newBrowser()
    browser.launch(url, 10000)
    var doc = browser.html() 
    browser.close()
    Console.log(doc)
    let data = [];
        // doc.select(".nav-links > *").forEach(item=> {
        //     if(item.select('.fa').length == 0 ){
        //         let check = item.attr('class').match(/current/)
        //         if(check){
        //             data.push({
        //                 name: item.text(),
        //                 url: url
        //             })
        //             Console.log(item.text())
        //         }else {
        //             data.push({
        //                 name: item.attr('title'),
        //                 url: item.attr('href'),
        //             })
        //         }
        //     }
        // })
        return Response.success(data);
    return Response.error("something went wrong")

}