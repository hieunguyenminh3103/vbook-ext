function execute() {
    return Response.success([
        {title: "Home", input: "https://foamgirl.net/", script: "gen.js"},
        {title: "Chinese", input: "https://foamgirl.net/chinese/", script: "gen.js"},
        {title: "Japan", input: "https://foamgirl.net/japan/", script: "gen.js"},
        {title: "Japan Aidol", input: "https://foamgirl.net/aidol/", script: "gen.js"},
        {title: "Japan Gravure", input: "https://foamgirl.net/gravure/", script: "gen.js"},
        {title: "Japan Magazine", input: "https://foamgirl.net/magazine/", script: "gen.js"},
        {title: "Korea", input: "https://foamgirl.net/korea/", script: "gen.js"},
        {title: "Thailand", input: "https://foamgirl.net/thailand/", script: "gen.js"},
        {title: "Cosplay", input: "https://foamgirl.net/cosplay/", script: "gen.js"},
    ]);
}
